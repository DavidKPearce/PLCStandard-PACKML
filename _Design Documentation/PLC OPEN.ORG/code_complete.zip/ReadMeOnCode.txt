The following zip files contain code that is part of the document Creating PLCopen Compliant Libraries V1_0 as published in May 2017. This code is as an example only and is not tested and need to be adapted to meet your requirements.
The files itself can be opened in any text editor and as such copied & pasted in to your existing development environments.
Feedback to PLCopen.org is appreciated.

Code.zip
Code_prefixed.zip
Code_prefixed_with_enum.zip

